# node-express-passport-mongoose-auth
This source code is part of [Node.js, Express.js, Mongoose.js and Passport.js Authentication tutorial](https://www.djamware.com/post/58bd823080aca7585c808ebf/nodejs-expressjs-mongoosejs-and-passportjs-authentication)

* Clone this repo
* Run 'npm install'
* Run 'npm start' or 'nodemon'

If you think this source code is useful, it will be great if you just give it star or just buy me a cup of cofee [![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=Q5WK24UVWUGBN)
