var connect = require('connect');
var app = connect();
app.listen(3000);
