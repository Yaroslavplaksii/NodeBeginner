1. Скачано с demos.itlessons.info
2. Статья http://www.itlessons.info/nodejs/auth-with-express-and-passportjs/

1. http://passportjs.org/guide/
2. https://github.com/stevebest/passport-vkontakte
3. http://expressjs.com/guide.html
4. http://jade-lang.com/reference/