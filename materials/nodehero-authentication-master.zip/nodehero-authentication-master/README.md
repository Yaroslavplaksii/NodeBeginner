# nodehero-authentication

1. `git clone git@github.com:RisingStack/nodehero-authentication.git`
2. `cd nodehero-authentication`
3. `npm install`
4. `REDIS_STORE_URI=redis://localhost REDIS_STORE_SECRET=my-strong-secret npm start`

## Pre requirements

- Running [Redis](https://redis.io/) database
